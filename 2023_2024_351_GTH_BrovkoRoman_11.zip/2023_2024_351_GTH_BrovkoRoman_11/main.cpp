#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <fstream>
#include <set>
#include <algorithm>
#include <queue>
#include "Graph.h"

using namespace std;
const int INF = 1e9 + 7;

int main()
{
    cout << "Enter the file with graph (example : a.txt) or enter \"empty\" for empty graph" << endl;
    string file;
    cin >> file;

    Graph g(0, 0);

    if (file == "empty") {
        bool isD, isW;
        cout << "Is the graph directed (1) or undirected (0) ?" << endl;
        cin >> isD;

        cout << "Is the graph weighted (1) or unweighted (0) ?" << endl;
        cin >> isW;

        g = Graph(isD, isW);
    }
    else g = Graph(file);

    g.print();

    string help = "You can enter commands:\nhelp\nhelp_with_files\nadd_vertex v\nadd_edge v u (for unweighted graphs) | add_edge v u w (for weighted graphs)\ndelete_vertex v\ndelete_edge v u\nprint\nprint_to_file file\ntask u v";
    cout << help << endl;

    while (true) {
        string cmd;
        cin >> cmd;

        if (cmd == "help") {
            cout << help << endl;
        }
        else if (cmd == "help_with_files") {
            cout << "The first 0 or 1 in file indicates if the graph is directed." << endl;
            cout << "The second 0 or 1 indicates if the graph is weighted" << endl;
            cout << "The next lines are adjacency list" << endl;
        }
        else if (cmd == "add_vertex") {
            string v;
            cin >> v;
            g.add_vertex(v);
        }
        else if (cmd == "add_edge") {
            string v, u;
            cin >> v >> u;

            if (g.isWeighted) {
                int w;
                cin >> w;
                g.add_edge(v, u, w);
            }
            else g.add_edge(v, u);
        }
        else if (cmd == "delete_vertex") {
            string v;
            cin >> v;
            g.delete_vertex(v);
        }
        else if (cmd == "delete_edge") {
            string v, u;
            cin >> v >> u;
            g.delete_edge(v, u);
        }
        else if (cmd == "print") {
            g.print();
        }
        else if (cmd == "print_to_file") {
            string file;
            cin >> file;
            g.print(file);
        }
		else if (cmd == "task") {
			string s, t;
			cin >> s >> t;

			if(!g.adj.count(s))
			{
				cout << "The vertex " << s << " doesn't exist" << endl;
				return 0;
			}

			if(!g.adj.count(t))
			{
				cout << "The vertex " << t << " doesn't exist" << endl;
				return 0;
			}

			if(s == t)
            {
                cout << "The vertices must not coincide" << endl;
                return 0;
            }

			if(!g.isWeighted)
			{
			    cout << "The graph must be weighted" << endl;
			    return 0;
			}

			map <string, vector <int> > G;

			vector <string> End;
			vector <int> P, F;

			for(auto p:g.adj)
                for(auto to:p.second)
                {
                    G[p.first].push_back(P.size());

                    End.push_back(to.first);
                    P.push_back(to.second);
                    F.push_back(0);

                    G[to.first].push_back(P.size());

                    End.push_back(p.first);
                    P.push_back(0);
                    F.push_back(0);
                }

            int flow = 0;

            while(true)
            {
                queue <string> q;

                q.push(s);
                set <string> used;
                map <string, int> par;

                while(!q.empty() && !used.count(t))
                {
                    string v = q.front();
                    q.pop();

                    for(auto to:G[v])
                        if(!used.count(End[to]) && P[to] - F[to] > 0)
                        {
                            used.insert(End[to]);
                            par[End[to]] = to;
                            q.push(End[to]);
                        }
                }

                if(!used.count(t))
                {
                    cout << flow << endl;
                    break;
                }

                int mn = INT_MAX;

                string cur = t;

                while(cur != s)
                {
                    int e = par[cur];

                    mn = min(mn, P[e] - F[e]);
                    cur = End[e ^ 1];
                }

                cur = t;

                while(cur != s)
                {
                    int e = par[cur];

                    F[e] += mn;
                    F[e ^ 1] -= mn;

                    cur = End[e ^ 1];
                }

                flow += mn;
            }
        }
        else cout << "Incorrect command" << endl;
    }
}
