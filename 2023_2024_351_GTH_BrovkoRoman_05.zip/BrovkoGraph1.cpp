﻿#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <fstream>
#include <set>
#include "Graph.h"

using namespace std;

set <string> used;
map <string, string> p;
bool acyclic;
Graph g(0, 0);

void dfs(string v)
{
    used.insert(v);

    for (auto to : g.adj[v])
    {
        string u = to.first;

        if (used.count(u))
        {
            if (!p.count(v) || u != p[v])
            {
                acyclic = false;
            }
        }
        else
        {
            p[u] = v;
            dfs(u);
        }
    }
}

int main()
{
    cout << "Enter the file with graph (example : a.txt) or enter \"empty\" for empty graph" << endl;
    string file;
    cin >> file;

    if (file == "empty") {
        bool isD, isW;
        cout << "Is the graph directed (1) or undirected (0) ?" << endl;
        cin >> isD;

        cout << "Is the graph weighted (1) or unweighted (0) ?" << endl;
        cin >> isW;

        g = Graph(isD, isW);
    }
    else g = Graph(file);
    
    g.print();

    string help = "You can enter commands:\nhelp\nhelp_with_files\nadd_vertex v\nadd_edge v u (for unweighted graphs) | add_edge v u w (for weighted graphs)\ndelete_vertex v\ndelete_edge v u\nprint\nprint_to_file file\ntask";
    cout << help << endl;

    while (true) {
        string cmd;
        cin >> cmd;

        if (cmd == "help") {
            cout << help << endl;
        }
        else if (cmd == "help_with_files") {
            cout << "The first 0 or 1 in file indicates if the graph is directed." << endl;
            cout << "The second 0 or 1 indicates if the graph is weighted" << endl;
            cout << "The next lines are adjacency list" << endl;
        }
        else if (cmd == "add_vertex") {
            string v;
            cin >> v;
            g.add_vertex(v);
        }
        else if (cmd == "add_edge") {
            string v, u;
            cin >> v >> u;

            if (g.isWeighted) {
                int w;
                cin >> w;
                g.add_edge(v, u, w);
            }
            else g.add_edge(v, u);
        }
        else if (cmd == "delete_vertex") {
            string v;
            cin >> v;
            g.delete_vertex(v);
        }
        else if (cmd == "delete_edge") {
            string v, u;
            cin >> v >> u;
            g.delete_edge(v, u);
        }
        else if (cmd == "print") {
            g.print();
        }
        else if (cmd == "print_to_file") {
            string file;
            cin >> file;
            g.print(file);
        }
        else if (cmd == "task") {
            if (g.isDirected) {
                cout << "The graph must be undirected" << endl;
                return 0;
            }
            else {
                acyclic = 1;
                used.clear();
                p.clear();

                for (auto v : g.adj)
                    if (!used.count(v.first))
                        dfs(v.first);

                if (acyclic)
                    cout << "The graph is acyclic" << endl;
                else cout << "The graph is not acyclic" << endl;
            }
        }
        else cout << "Incorrect command" << endl;
    }
}
