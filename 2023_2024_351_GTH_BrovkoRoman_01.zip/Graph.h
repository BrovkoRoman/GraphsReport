#pragma once
#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <fstream>
#include <set>

using namespace std;

class Graph
{
public:
    map <string, set <pair <string, int> > > adj; // ��������� ��� ������ ���������
    bool isDirected;
    bool isWeighted;

    Graph(bool isDir, bool isW) { isDirected = isDir, isWeighted = isW; } // ����������� ������� �����
    Graph(bool isDir, bool isW, int n) : Graph(isDir, isW) { // ������ ����
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
            {
                adj[to_string(i)].insert({ to_string(j), 1 });
            }
    }
    Graph(string file) { // ���� �� �����
        ifstream fin(file);
        fin >> isDirected >> isWeighted;

        while (!fin.eof()) {
            string v;
            fin >> v;

            if (v.empty())
                continue;

            adj[v] = {};

            string s;
            getline(fin, s);
            s += ' ';

            string buf;

            if (!isWeighted) {
                for (int i = 3; i < s.size(); i++) {
                    if (s[i] == ' ') {
                        if (buf.empty())
                            continue;

                        adj[v].insert({ buf, 1 });
                        buf = "";
                    }
                    else buf += s[i];
                }
            }
            else {
                for (int i = 3; i < s.size(); i++) {
                    if (s[i] == ' ') {
                        if (buf.size() >= 1) // �������� ����������� ������ �� ������
                            buf = buf.substr(1, buf.size() - 1);

                        if (buf.empty())
                            continue;

                        int w = 0;
                        int sign = 1;

                        while (i < s.size() && s[i] == ' ' || s[i] == '-' || s[i] >= '0' && s[i] <= '9') {

                            if (s[i] != ' ') {
                                if (s[i] == '-')
                                    sign = -1;
                                else w = w * 10 + s[i] - '0';
                            }

                            i++; // ����� ���� � ����� ����� ����������� ������, ��� ����������� � ������� i++ �������� �����
                        }

                        w *= sign;

                        adj[v].insert({ buf, w });
                        buf = "";
                    }
                    else buf += s[i];
                }
            }
        }

        for (auto adjOfv : adj) // pair <string, set <pair <string, int> > >
            for (auto to : adjOfv.second) // pair <string, int>
                if (!adj.count(to.first)) {
                    cout << "Error : the vertex " << to.first << " doesn't exist" << endl;
                    exit(0);
                }

    }
    Graph(const Graph& g) { // ����������� �����������
        adj = g.adj;
        isDirected = g.isDirected;
        isWeighted = g.isWeighted;
    }

    void print() { // ����� �����
        cout << isDirected << ' ' << isWeighted << endl;
        for (auto Pair : adj) {
            cout << Pair.first << " - ";

            for (auto ver : Pair.second) {
                if (isWeighted)
                    cout << "(" << ver.first << ' ' << ver.second << ") ";
                else cout << ver.first << ' ';
            }

            cout << endl;
        }
    }
    void print(string file) { // ����� ����� � ����
        ofstream fout(file);

        fout << isDirected << ' ' << isWeighted << endl;
        for (auto Pair : adj) {
            fout << Pair.first << " - ";

            for (auto ver : Pair.second) {
                if (isWeighted)
                    fout << "(" << ver.first << ' ' << ver.second << ") ";
                else fout << ver.first << ' ';
            }

            fout << endl;
        }
    }

    void add_vertex(string v) { // ���������� �������
        if (adj.count(v)) {
            cout << "Error in add_vertex : the vertex already exists" << endl;
            return;
        }

        adj[v] = {};
    }
    void add_edge(string v, string u) { // ���������� ������������� �����
        if (isWeighted) {
            cout << "Error in add_edge : the given graph is weighted";
            return;
        }

        if (!adj.count(v) || !adj.count(u)) {
            cout << "Error in add_edge : some of given vertices don't exist" << endl;
            return;
        }

        auto it = adj[v].lower_bound({ u, INT_MIN });

        if (it != adj[v].end() && (*it).first == u) {
            cout << "Error in add_edge : the edge already exists" << endl;
            return;
        }

        adj[v].emplace(u, 1);

        if (!isDirected)
            adj[u].emplace(v, 1);
    }
    void add_edge(string v, string u, int w) { // ���������� ����������� �����
        if (!isWeighted) {
            cout << "Error in add_edge : the given graph is not weighted";
            return;
        }
        if (!adj.count(v) || !adj.count(u)) {
            cout << "Error in add_edge : some of given vertices don't exist" << endl;
            return;
        }

        auto it = adj[v].lower_bound({ u, INT_MIN });

        if (it != adj[v].end() && (*it).first == u) {
            cout << "Error in add_edge : the edge already exists" << endl;
            return;
        }

        adj[v].emplace(u, w);

        if (!isDirected)
            adj[u].emplace(v, w);
    }

    void delete_vertex(string v) { // �������� �������
        if (!adj.count(v)) {
            cout << "Error in delete_vertex : the vertex doesn't exist" << endl;
            return;
        }

        if (!isDirected) {
            while (!adj[v].empty()) {
                int sz = adj[v].size();

                auto ver = *adj[v].begin();

                auto it = adj[ver.first].find({ v, ver.second });
                adj[ver.first].erase(it);

                if (adj[v].size() == sz)
                    adj[v].erase(adj[v].begin());
            }
        }

        adj.erase(v);
    }

    void delete_edge(string v, string u) { // �������� �����
        if (!adj.count(v) || !adj.count(u)) {
            cout << "Error in delete_edge : some of given vertices don't exist" << endl;
            return;
        }

        auto it = adj[v].lower_bound({ u, INT_MIN });

        if (it == adj[v].end() || (*it).first != u) {
            cout << "Error in delete_edge : the edge doesn't exist" << endl;
            return;
        }

        adj[v].erase(it);

        if (v != u && !isDirected) {
            auto it = adj[u].lower_bound({ v, INT_MIN });

            if (it == adj[u].end() || (*it).first != v) {
                cout << "Error in delete_edge: the inverse edge doesn't exist";
                exit(0);
            }

            adj[u].erase(it);
        }
    }
};
