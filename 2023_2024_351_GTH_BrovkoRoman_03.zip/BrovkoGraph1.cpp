﻿#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <fstream>
#include <set>
#include "Graph.h"

using namespace std;


int main()
{
    cout << "Enter the file with graph (example : a.txt) or enter \"empty\" for empty graph" << endl;
    string file;
    cin >> file;

    Graph g(0, 0);

    if (file == "empty") {
        bool isD, isW;
        cout << "Is the graph directed (1) or undirected (0) ?" << endl;
        cin >> isD;

        cout << "Is the graph weighted (1) or unweighted (0) ?" << endl;
        cin >> isW;

        g = Graph(isD, isW);
    }
    else g = Graph(file);
    
    g.print();

    string help = "You can enter commands:\nhelp\nhelp_with_files\nadd_vertex v\nadd_edge v u (for unweighted graphs) | add_edge v u w (for weighted graphs)\ndelete_vertex v\ndelete_edge v u\nprint\nprint_to_file file\ntask u v";
    cout << help << endl;

    while (true) {
        string cmd;
        cin >> cmd;

        if (cmd == "help") {
            cout << help << endl;
        }
        else if (cmd == "help_with_files") {
            cout << "The first 0 or 1 in file indicates if the graph is directed." << endl;
            cout << "The second 0 or 1 indicates if the graph is weighted" << endl;
            cout << "The next lines are adjacency list" << endl;
        }
        else if (cmd == "add_vertex") {
            string v;
            cin >> v;
            g.add_vertex(v);
        }
        else if (cmd == "add_edge") {
            string v, u;
            cin >> v >> u;

            if (g.isWeighted) {
                int w;
                cin >> w;
                g.add_edge(v, u, w);
            }
            else g.add_edge(v, u);
        }
        else if (cmd == "delete_vertex") {
            string v;
            cin >> v;
            g.delete_vertex(v);
        }
        else if (cmd == "delete_edge") {
            string v, u;
            cin >> v >> u;
            g.delete_edge(v, u);
        }
        else if (cmd == "print") {
            g.print();
        }
        else if (cmd == "print_to_file") {
            string file;
            cin >> file;
            g.print(file);
        }
        else if (cmd == "task") {
            string u, v;
            cin >> u >> v;
            if (!g.isDirected) {
                cout << "The graph must be directed" << endl;
                return 0;
            }
            else if (!g.adj.count(u) || !g.adj.count(v)) {
                cout << "Some of given vertices don't exist" << endl;
                return 0;
            }
            else {
                map <string, int> vertices;

                for (auto v : g.adj)
                    vertices[v.first] = 0;

                for (auto to : g.adj[v])
                    vertices[to.first]++;

                for (auto to : g.adj[u])
                    vertices[to.first]++;

                for (auto p : vertices)
                    if (p.second == 2)
                        cout << p.first << endl;
            }
        }
        else cout << "Incorrect command" << endl;
    }
}
