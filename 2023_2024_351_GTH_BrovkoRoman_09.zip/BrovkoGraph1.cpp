﻿#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <fstream>
#include <set>
#include <algorithm>
#include "Graph.h"

using namespace std;
const int INF = 1e9 + 7;

int main()
{
    cout << "Enter the file with graph (example : a.txt) or enter \"empty\" for empty graph" << endl;
    string file;
    cin >> file;

    Graph g(0, 0);

    if (file == "empty") {
        bool isD, isW;
        cout << "Is the graph directed (1) or undirected (0) ?" << endl;
        cin >> isD;

        cout << "Is the graph weighted (1) or unweighted (0) ?" << endl;
        cin >> isW;

        g = Graph(isD, isW);
    }
    else g = Graph(file);
    
    g.print();

    string help = "You can enter commands:\nhelp\nhelp_with_files\nadd_vertex v\nadd_edge v u (for unweighted graphs) | add_edge v u w (for weighted graphs)\ndelete_vertex v\ndelete_edge v u\nprint\nprint_to_file file\ntask u v1 v2";
    cout << help << endl;

    while (true) {
        string cmd;
        cin >> cmd;

        if (cmd == "help") {
            cout << help << endl;
        }
        else if (cmd == "help_with_files") {
            cout << "The first 0 or 1 in file indicates if the graph is directed." << endl;
            cout << "The second 0 or 1 indicates if the graph is weighted" << endl;
            cout << "The next lines are adjacency list" << endl;
        }
        else if (cmd == "add_vertex") {
            string v;
            cin >> v;
            g.add_vertex(v);
        }
        else if (cmd == "add_edge") {
            string v, u;
            cin >> v >> u;

            if (g.isWeighted) {
                int w;
                cin >> w;
                g.add_edge(v, u, w);
            }
            else g.add_edge(v, u);
        }
        else if (cmd == "delete_vertex") {
            string v;
            cin >> v;
            g.delete_vertex(v);
        }
        else if (cmd == "delete_edge") {
            string v, u;
            cin >> v >> u;
            g.delete_edge(v, u);
        }
        else if (cmd == "print") {
            g.print();
        }
        else if (cmd == "print_to_file") {
            string file;
            cin >> file;
            g.print(file);
        }
		else if (cmd == "task") {
			string u, v1, v2;
			cin >> u >> v1 >> v2;

			if (!g.adj.count(u))
			{
				cout << "The vertex " << u << " doesn't exist" << endl;
				return 0;
			}

			if (!g.adj.count(v1))
			{
				cout << "The vertex " << v1 << " doesn't exist" << endl;
				return 0;
			}

			if (!g.adj.count(v2))
			{
				cout << "The vertex " << v2 << " doesn't exist" << endl;
				return 0;
			}

			map <pair <string, string>, int> d;

			for (auto p1 : g.adj)
				for (auto p2 : g.adj)
					d[{p1.first, p2.first}] = INF;

			for (auto p1 : g.adj)
				d[{p1.first, p1.first}] = 0;

			for (auto p1 : g.adj)
				for (auto to : p1.second)
					d[{p1.first, to.first}] = min(d[{p1.first, to.first}], to.second);

			for(auto p1:g.adj)
				for(auto p2:g.adj)
					for (auto p3 : g.adj)
					{
						string u = p1.first, i = p2.first, j = p3.first;

						d[{i, j}] = min(d[{i, j}], d[{i, u}] + d[{u, j}]);
					}

			cout << (d[{u, v1}] > INF / 2 ? "inf" : to_string(d[{u, v1}])) << ' ' << (d[{u, v2}] > INF / 2 ? "inf" : to_string(d[{u, v2}])) << endl;
        }
        else cout << "Incorrect command" << endl;
    }
}
